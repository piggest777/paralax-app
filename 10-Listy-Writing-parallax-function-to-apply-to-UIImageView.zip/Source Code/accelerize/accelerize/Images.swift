//
//  Images.swift
//  accelerize
//
//  Created by Caleb Stultz on 10/16/17.
//  Copyright © 2017 Caleb Stultz. All rights reserved.
//

import UIKit

var camera = UIImage(named: "1")!
var city = UIImage(named: "2")!
var animal = UIImage(named: "3")!
var flowers = UIImage(named: "4")!
var stand = UIImage(named: "5")!
var urban = UIImage(named: "6")!

var imageArray = [camera, city, animal, flowers, stand, urban]
var nameArray = ["CAMERAS", "CITY", "ANIMALS", "FLOWERS", "STANDS", "URBAN"]
